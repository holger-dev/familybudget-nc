<?php
// Keep legacy handles for now? No — after rename we use new handle
script('familybudget', 'familybudget');
style('familybudget', 'familybudget');
?>
<div class="app-familybudget"></div>
